import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-payments',
  templateUrl: './admin-payments.component.html',
  styleUrls: ['./admin-payments.component.css']
})
export class AdminPaymentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
