export class Course {
 courseId:number
 courseStatus:String
 courseProgress:number
 endDate:Date
 tech:number
 techName:string
 mentor:number
 user:number
}
