import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-skills',
  templateUrl: './mentor-skills.component.html',
  styleUrls: ['./mentor-skills.component.css']
})
export class MentorSkillsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
