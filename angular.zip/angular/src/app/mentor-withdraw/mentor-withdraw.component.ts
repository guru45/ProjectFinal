import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-withdraw',
  templateUrl: './mentor-withdraw.component.html',
  styleUrls: ['./mentor-withdraw.component.css']
})
export class MentorWithdrawComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
