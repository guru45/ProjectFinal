export class Search {
    firstname:string
    skills:string
    qualification:string
}
