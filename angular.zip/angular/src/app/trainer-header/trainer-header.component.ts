import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainer-header',
  templateUrl: './trainer-header.component.html',
  styleUrls: ['./trainer-header.component.css']
})
export class TrainerHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
