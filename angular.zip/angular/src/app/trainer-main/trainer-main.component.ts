import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainer-main',
  templateUrl: './trainer-main.component.html',
  styleUrls: ['./trainer-main.component.css']
})
export class TrainerMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
