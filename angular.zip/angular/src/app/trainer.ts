export class Trainer 

{
    firstname:string
    lastname:string
    Phone:number
    age:number
    email:string
    skills:string
    linkdin:string
    password:string
    qualification:string
}

