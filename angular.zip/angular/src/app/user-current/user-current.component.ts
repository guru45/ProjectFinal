import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-current',
  templateUrl: './user-current.component.html',
  styleUrls: ['./user-current.component.css']
})
export class UserCurrentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
