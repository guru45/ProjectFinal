export class User {
    firstname:string
    lastname:string
    Phone:number
    age:number
    email:string
    id:number
    linkdin:string
    password:string
    
}
