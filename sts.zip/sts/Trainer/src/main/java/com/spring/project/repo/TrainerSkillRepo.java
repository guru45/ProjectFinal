package com.spring.project.repo;

import org.springframework.data.repository.CrudRepository;

import com.spring.project.pojo.Trainerskill;



public interface TrainerSkillRepo extends CrudRepository<Trainerskill, String>{

}
